package com.zybooks.p2_dawneengraham;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<DailyWeight> dataList;
    private Context context;
    private OnItemClickListener listener;

    // Adds a constructor to set the listener
    public MyAdapter(List<DailyWeight> dataList, Context context) {
        this.dataList = dataList;
        this.context = context;
    }

    // Defines the interface for the item click listener
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    // Method sets listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        DailyWeight data = dataList.get(position);
        holder.bind(data);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private EditText weight;
        private TextView date;

        private Button adjustButton;
        private Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            weight = itemView.findViewById(R.id.labelEditWeight);
            date = itemView.findViewById(R.id.dataTextView);
            adjustButton = itemView.findViewById(R.id.adjustButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);

            // OnClickListener for the delete button
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        dataList.remove(position);
                        notifyItemRemoved(position);
                    }
                }
            });

            // Sets OnClickListener for item view
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position); // Call the listener's onItemClick method
                        }
                    }
                }
            });
        }

        public void bind(DailyWeight data) {
            weight.setText(String.valueOf(data.getWeight()));
            date.setText(data.getDate());
        }
    }
}
