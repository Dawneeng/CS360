package com.zybooks.p2_dawneengraham;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.TextView;


public class MenuActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        // LinearLayout linearLayout = findViewById(R.id.linearLayout);
        //View inflatedView = LayoutInflater.from(this).inflate(R.layout.my_inflated_view, null);
        //layout.addView(inflatedView);

        TextView settingText = findViewById(R.id.settingText);
        settingText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        TextView dataDisplayText = findViewById(R.id.weightText);
        dataDisplayText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            }
        });

        TextView signOutText = findViewById(R.id.signOutText);
        signOutText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

}
