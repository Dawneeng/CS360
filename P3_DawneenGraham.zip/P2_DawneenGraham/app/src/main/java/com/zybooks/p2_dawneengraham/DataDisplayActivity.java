package com.zybooks.p2_dawneengraham;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<DailyWeight> dataList;
    private static final int EDIT_REQUEST_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_display);

        recyclerView = findViewById(R.id.recyclerView);
        Button addDataButton = findViewById(R.id.addDataButton);

        // dataList
        dataList = new ArrayList<>();
        //dataList.add(new DailyWeight(100));
        //dataList.add(new DailyWeight(230));
        SQLiteDatabase database = 



        //  RecyclerView and adapter
        adapter = new MyAdapter(dataList, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setAdapter(adapter);

        // OnClickListener for the RecyclerView items
        adapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                //To open an editing dialog or activity
                DailyWeight selectedItem = dataList.get(position);
                openEditDataDialog(selectedItem, position);
            }
        });

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // When clicked adds new data
                dataList.add(new DailyWeight(200));
                adapter.notifyItemInserted(dataList.size() - 1);

                // Notifies the user that data has been added
                Toast.makeText(DataDisplayActivity.this, "Weight was added", Toast.LENGTH_SHORT).show();
            }
        });

    }

    // Defines a method to open an editing dialog
    private void openEditDataDialog(final DailyWeight selectedItem, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Data");

        // Creates an EditText for editing the data
        final EditText editText = new EditText(this);
        editText.setText(selectedItem.getText()); // Set the current data
        builder.setView(editText);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Save the edited data and update the RecyclerView
                String editedData = editText.getText().toString();
                selectedItem.setText(editedData);
                adapter.notifyItemChanged(position);
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.create().show();
    }

}
