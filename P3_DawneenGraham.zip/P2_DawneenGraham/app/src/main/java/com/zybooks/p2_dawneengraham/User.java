package com.zybooks.p2_dawneengraham;

public class User {
    private String email;
    private String password;
    private int goalID;
    private int dailyID;

    public User() {
        // Default constructor
    }

    public User(String email, String password, int goalID, int dailyID) {
        this.email = email;
        this.password = password;
        this.goalID = goalID;
        this.dailyID = dailyID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getGoalID() {
        return goalID;
    }

    public void setGoalID(int goalID) {
        this.goalID = goalID;
    }

    public int getDailyID() {
        return dailyID;
    }

    public void setDailyID(int dailyID) {
        this.dailyID = dailyID;
    }
}

