package com.zybooks.p2_dawneengraham;
import com.zybooks.p2_dawneengraham.GoalWeight;
import com.zybooks.p2_dawneengraham.DailyWeight;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;
import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int VERSION = 1;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UsersTable {
        private static final String TABLE = "Users";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASSWORD = "password";
        private static final String COL_GOAL_ID = "goalID";
        private static final String COL_DAILY_ID = "dailyWeightID";
    }

    private static final class GoalWeightsTable {
        private static final String TABLE = "GoalWeights";
        private static final String COL_GOAL_WEIGHT = "goalWeight";
        private static final String COL_GOAL_ID = "goalID";
    }

    private static final class DailyWeightsTable {
        private static final String TABLE = "DailyWeights";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_DATE = "date";
        private static final String COL_DAILY_WEIGHT_ID = "dailyWeightID";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + UsersTable.TABLE + " (" +
                UsersTable.COL_EMAIL + " TEXT PRIMARY KEY, " +
                UsersTable.COL_PASSWORD + " TEXT, " +
                UsersTable.COL_GOAL_ID + " INTEGER, " +
                UsersTable.COL_DAILY_ID + " INTEGER, " +
                //"FOREIGN KEY (" + UsersTable.COL_GOAL_ID)";
                "FOREIGN KEY (goalID) REFERENCES GoalWeights(goalID)," +
                "FOREIGN KEY (dailyWeightID) REFERENCES DailyWeights(dailyWeightID))";


        String createGoalWeightsTable = "CREATE TABLE " + GoalWeightsTable.TABLE + " (" +
                GoalWeightsTable.COL_GOAL_WEIGHT + " REAL, " +
                GoalWeightsTable.COL_GOAL_ID + " INTEGER)";

        String createDailyWeightsTable = "CREATE TABLE " + DailyWeightsTable.TABLE + " (" +
                DailyWeightsTable.COL_WEIGHT + " REAL, " +
                DailyWeightsTable.COL_DATE + " TEXT, " +
                DailyWeightsTable.COL_DAILY_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT)";


        db.execSQL(createUserTable);
        db.execSQL(createGoalWeightsTable);
        db.execSQL(createDailyWeightsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UsersTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + GoalWeightsTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DailyWeightsTable.TABLE);
        onCreate(db);
    }

    // Access methods for the Users table
    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_EMAIL, user.getEmail());
        values.put(UsersTable.COL_PASSWORD, user.getPassword());
        values.put(UsersTable.COL_GOAL_ID, user.getGoalID());
        values.put(UsersTable.COL_DAILY_ID, user.getDailyID());

        long userId = db.insert(UsersTable.TABLE, null, values);
        db.close();
        return userId;
    }

    public int deleteUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(UsersTable.TABLE, UsersTable.COL_EMAIL + " = ?", new String[]{email});
        db.close();
        return rowsDeleted;
    }

    public int updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_PASSWORD, user.getPassword());
        values.put(UsersTable.COL_GOAL_ID, user.getGoalID());
        values.put(UsersTable.COL_DAILY_ID, user.getDailyID());

        int rowsUpdated = db.update(UsersTable.TABLE, values, UsersTable.COL_EMAIL + " = ?", new String[]{user.getEmail()});
        db.close();
        return rowsUpdated;
    }

    @SuppressLint("Range")
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + UsersTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setEmail(cursor.getString(cursor.getColumnIndex(UsersTable.COL_EMAIL)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(UsersTable.COL_PASSWORD)));
                user.setGoalID(cursor.getInt(cursor.getColumnIndex(UsersTable.COL_GOAL_ID)));
                user.setDailyID(cursor.getInt(cursor.getColumnIndex(UsersTable.COL_DAILY_ID)));
                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return userList;
    }

    // Data access methods for the GoalWeights table
    public long addGoalWeight(GoalWeight goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightsTable.COL_GOAL_WEIGHT, goalWeight.getGoalWeight());
        values.put(GoalWeightsTable.COL_GOAL_ID, goalWeight.getGoalID());

        long goalWeightId = db.insert(GoalWeightsTable.TABLE, null, values);
        db.close();
        return goalWeightId;
    }

    public int deleteGoalWeight(int goalID) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(GoalWeightsTable.TABLE, GoalWeightsTable.COL_GOAL_ID + " = ?", new String[]{String.valueOf(goalID)});
        db.close();
        return rowsDeleted;
    }

    public int updateGoalWeight(GoalWeight goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightsTable.COL_GOAL_WEIGHT, goalWeight.getGoalWeight());

        int rowsUpdated = db.update(GoalWeightsTable.TABLE, values, GoalWeightsTable.COL_GOAL_ID + " = ?", new String[]{String.valueOf(goalWeight.getGoalID())});
        db.close();
        return rowsUpdated;
    }

    public List<GoalWeight> getAllGoalWeights() {
        List<GoalWeight> goalWeightList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + GoalWeightsTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                GoalWeight goalWeight = new GoalWeight();
               // goalWeight.setGoalWeight(cursor.getDouble(cursor.getColumnIndex(GoalWeightsTable.COL_GOAL_WEIGHT)));
                //goalWeight.setGoalID(cursor.getInt(cursor.getColumnIndex(GoalWeightsTable.COL_GOAL_ID)));
                goalWeightList.add(goalWeight);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return goalWeightList;
    }

    // Data access methods for the DailyWeights table
    public long addDailyWeight(DailyWeight dailyWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightsTable.COL_WEIGHT, dailyWeight.getWeight());
        values.put(DailyWeightsTable.COL_DATE, dailyWeight.getDate());

        long dailyWeightId = db.insert(DailyWeightsTable.TABLE, null, values);
        db.close();
        return dailyWeightId;
    }

    public int deleteDailyWeight(int dailyWeightID) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(DailyWeightsTable.TABLE, DailyWeightsTable.COL_DAILY_WEIGHT_ID + " = ?", new String[]{String.valueOf(dailyWeightID)});
        db.close();
        return rowsDeleted;
    }

    public int updateDailyWeight(DailyWeight dailyWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightsTable.COL_WEIGHT, dailyWeight.getWeight());
        values.put(DailyWeightsTable.COL_DATE, dailyWeight.getDate());

        int rowsUpdated = db.update(DailyWeightsTable.TABLE, values, DailyWeightsTable.COL_DAILY_WEIGHT_ID + " = ?", new String[]{String.valueOf(dailyWeight.getDailyWeightID())});
        db.close();
        return rowsUpdated;
    }

    public List<DailyWeight> getAllDailyWeights() {
        List<DailyWeight> dailyWeightList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + DailyWeightsTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                DailyWeight dailyWeight = new DailyWeight();
                //dailyWeight.setDailyWeightID(cursor.getInt(cursor.getColumnIndex(DailyWeightsTable.COL_DAILY_WEIGHT_ID)));
                //dailyWeight.setWeight(cursor.getDouble(cursor.getColumnIndex(DailyWeightsTable.COL_WEIGHT)));
                //dailyWeight.setDate(cursor.getString(cursor.getColumnIndex(DailyWeightsTable.COL_DATE)));
                dailyWeightList.add(dailyWeight);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return dailyWeightList;
    }
}

