package com.zybooks.p2_dawneengraham;

public class GoalWeight {
    private double goalWeight;
    private int goalID;

    public GoalWeight() {
        // Default constructor
    }

    public GoalWeight(double goalWeight, int goalID) {
        this.goalWeight = goalWeight;
        this.goalID = goalID;
    }

    public double getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(double goalWeight) {
        this.goalWeight = goalWeight;
    }

    public int getGoalID() {
        return goalID;
    }

    public void setGoalID(int goalID) {
        this.goalID = goalID;
    }
}

