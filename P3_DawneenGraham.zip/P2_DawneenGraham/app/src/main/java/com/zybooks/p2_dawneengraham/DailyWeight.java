package com.zybooks.p2_dawneengraham;

public class DailyWeight {
    private double weight;
    private String date;
    private int dailyWeightID;

    public DailyWeight() {
        // Default constructor
    }

    public DailyWeight(double weight, String date, int dailyWeightID) {
        this.weight = weight;
        this.date = date;
        this.dailyWeightID = dailyWeightID;
    }

    public DailyWeight(double weight) {
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getDailyWeightID() {
        return dailyWeightID;
    }

    public void setDailyWeightID(int dailyWeightID) {
        this.dailyWeightID = dailyWeightID;
    }

    public int getText() {
        return (int) this.weight;
    }

    public void setText(String editedData) {
    }
}
