package com.zybooks.p2_dawneengraham;

public class DataModel {
    private String text;

    // Constructor
    public DataModel(String text) {
        this.text = text;
    }

    // Getter method
    public String getText() {
        return text;
    }

    // Setter method
    public void setText(String text) {
        this.text = text;
    }
}
